/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author silvi
 */
public class CajaBanco {

    private int numero;
    private boolean ocupado;

    public CajaBanco(int n) {

        numero = n;
        ocupado = true;

    }

    public void setNumero(int n) {
        this.numero = n;
    }

    public int getNumero() {
        return numero;
    }

    public void setOcupado(boolean o) {
        this.ocupado = o;
    }

    public boolean getOcupado() {
        return ocupado;
    }
}
