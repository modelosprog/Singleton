/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author silvi
 */
public class AtencionCajero {

    private static AtencionCajero listo;
    public CajaBanco[] cajasBanco;

    private AtencionCajero() {

        cajasBanco = new CajaBanco[4];
        for (int i = 0; i < 4; i++) {
            cajasBanco[i] = new CajaBanco(i);
        }
    }

    public static AtencionCajero atender() {
        if (listo == null) {
            listo = new AtencionCajero();
        }
        return listo;
    }
    
    public CajaBanco getCajero(){
        for(int i=0; i<4; i++)
            if(cajasBanco[i].getOcupado()){
                System.out.println("asignando cajero "+cajasBanco[i].getNumero());
                cajasBanco[i].setOcupado(false);
                return cajasBanco[i];
            }
                
        return null;
    }
    
    public void liberarCajero(CajaBanco c){
        System.out.println("liberando cajero "+c.getNumero());
                
        c.setOcupado(true);
    }
    

}
    