
import java.util.Scanner;


public class Singleton {

 
    public static void main(String[] args) {

        CajaBanco[] cajeros = new CajaBanco[4]; 
        
             AtencionCajero s;
        int estado;
       
        Scanner sc = new Scanner(System.in);
        s = AtencionCajero.atender();
        for(int i=0; i<4; i++){
            System.out.println("Ingrese 1 si necesita un cajero");
            estado = sc.nextInt();
            
            if(estado==1){
                cajeros[i] = s.getCajero();
            }else{
                
            meterle otro scanner que pregunte el cajero que libera, verificar que los scanners cumplan las condiciones (1)y(1.2.3.4)
            }
            
            
            System.out.println("cajero"+ (i+1) + " = "+ cajeros[i] );
            

       
        }
    }
}
